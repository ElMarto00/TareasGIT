package ejerciciosResueltos;

import java.util.*;

public class Ejercicio3 {

/**
 * Calcular suma cuadrados
 */

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int a, b, suma;
        System.out.println("Introduce un numero: ");
        a = teclado.nextInt();
        System.out.println("Introduce otro: ");
        b = teclado.nextInt();
        suma = (a * a) + (b * b);
        System.out.println("La suma de sus cuadrados es: " + suma);
    }
}
//NUEVA